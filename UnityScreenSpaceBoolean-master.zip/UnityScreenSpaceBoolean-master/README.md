Unity Screen Space Boolean
==========================
![Demo 1](https://raw.githubusercontent.com/wiki/hecomi/UnityScreenSpaceBoolean/Demo1.gif)
![Demo 2](https://raw.githubusercontent.com/wiki/hecomi/UnityScreenSpaceBoolean/Demo2.gif)

Reference
---------
- [i-saint/Unity5Effects](https://github.com/i-saint/Unity5Effects)

Article
-------
- [Unity でスクリーンスペースのブーリアン演算をやってみた - 凹みTips](http://tips.hecomi.com/entry/2016/09/10/191006)

License
-------
<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.
